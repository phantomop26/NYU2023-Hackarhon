# nyu2023hackathon
GimmeSpace website from the 2023 nyu hackathon 2/18-2/19
